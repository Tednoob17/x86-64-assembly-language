Ceci s'inspire du fork de la documentation du rust book  par l'universite Brown 
Dans cet fork il y a une version interactive avec les users , un dossiers quizzes
est creer a la racine contenant des fichier toml 

Nous sommes dans un fork de rust-book faite par l'universite brown qui est assez differentes du document de base
lis le content de de l'intro experiment-intro.md / experiment-intro.html

- dans src il y a des fichiers qui ne nous interesse pas mais ici on ne sera pas la pour parler de rust mais de x86-64 

- Un dossier nommer js-extension contenant des packages (je les aient directement copier depuis la base) 

- il est possible que certains dossiers ici n'aient pas leurs places ici verifie dans le dossier js-extension si le contenus
nous sera utiles

- Corrige les fautes de grammaires et de vocabulaires, car c'est possible que j'ai voulu aussi expliquer
certains trucs et ou je me suis embrouiller donc lis chaue chapites chaque section et lis ce ue j'ai mis si il
faut reformuler reformule sans perdre l'essence du contenu

- les fichiers .toml peuvent etre mal ecrit ou peuvent contenir des choses qui ne nous sont pas utiles dans notres contextes

- le dossiers quizzes contients des fichiers .toml dans le dossier quizzes/examples/ ,  qui montre la structures des 
questions utiliser, ils sont tirer des question du livre programming de rust

- check tout les fichiers de l'architecture pour savoir s'ils seront utile ou pas comme le rust-toolchain, rustfmt.toml, makefile.toml
verifie leurs utiliter et s'il faut corriger des choses a l'interieurm pareil pour le dossier ci

https://github.com/cognitive-engineering-lab/mdbook-quiz

Pour les quizzed il y a un fichier quizzes-n.txt qui se trouve dans chaque dossier contenant des exos
ils contiennent les questions et en dessous se trouves 'R:' contenant la reponse. 

- check le style-guide.md pour voir si ca doit etre fixe

en gros tu dois ajuster le content pour qu'il match avec ce qu'on veux raconter

- It also important when a reader read a sentences / phrase it understand why one word is in '** **'
why another is in backstick ``, why another is in simple '* *'.
- And if possible we can work in collaboration to design a phrase patters who can just be a example of
how it can woork and example who can match what we want
   
- What can fix a title ? , A template of file content ?

- Si il y a des parentheses mal placer, des explications faite au mauvais endoit une structures mal gerer
 
- Pendant certains moment j'ai oublier de mettre les notations par chapitre like 1.1, 1.2, 5.3 etc check bien

- possible que certaines syntaxe soit mal ecrite comme cette des insertion d'images si t'en vois fix les 

